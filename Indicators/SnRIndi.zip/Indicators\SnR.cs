// SnR Indicator v1.01     
// Copyright (C) 2016, fxborg<fxborg-labo.hateblo.jp>.
// http://fxborg-labo.hateblo.jp/ 
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

#endregion

//This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
    /// <summary>
    /// Accel Moving Average
    /// </summary>
    public class SnR : Indicator
    {

		private double 										up;
		private double 										dn;
		private double 										up2;
		private double 										dn2;

        private int bo_flg = 0;
		private MAX max;
		private MIN min;
		private LasyATR										atr; 
        
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                //---パラメータのデフォルト値を設定。
                Description = "SnR";
                Name = "SnR";
                IsSuspendedWhileInactive    = true;
                IsOverlay                   = true;
				Size1=0.3;
				Size2=1;
				Size3=2;
				Size4=6;
				Period=30;
				LookBack=120;
				AddPlot(new Stroke(Brushes.Red),  PlotStyle.Hash, "Upper");
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.Hash, "Lower");
            }
            else if (State == State.Historical)
            {
				atr	= LasyATR(50);
				min = MIN(Low,Period);
				max = MAX(High,Period);
                Plots[0].Width=2;        	
				Plots[1].Width=2;        	
		        Plots[0].Brush=Brushes.Red;        	
				Plots[1].Brush=Brushes.DodgerBlue;        	
		
				//---
            }
        }
        
        protected override void OnBarUpdate()
        {
            if(CurrentBar<1)return;
			
            if(CurrentBar<=2)
			{
				
				up=up2=max[0];
				dn=dn2=min[0];
				return;
			}	
			//---
            double atr0 = atr[0];
            double min0=min[0];
            double max0=max[0];
            double h0=High[0];
            double l0=Low[0];
            double c0=Close[0];
     		double size1=Size1*atr0;
     		double size2=Size2*atr0;
     		double size3=Size3*atr0;
     		double size4=Size4*atr0;
            //+-------------------------------------------------+
            //| up trend 
            //+-------------------------------------------------+

            if (h0 > up2)      								{ up2 = h0;} //もっと上がる
            if (l0 < dn2)      								{ dn2 = l0;} // もっと下がる                        

			//+-------------------------------------------------+
            //| expand
            //+-------------------------------------------------+

            if ( bo_flg == -1 && c0 > dn2 + size2)
			{ 
				bo_flg = 0;
				if(up-dn2>size4)
				{
					if(dn-dn2>size3 && dn>Math.Max(High[0],Close[1]))	up2=up=dn;
					else
					{
						double y=h0;
						
						for(int j=0;j<LookBack;j++)
						{
							if(High[j] > y) y = High[j];					
							if(up<y)break;
							if(y-dn2 > size2 && High[j] < y - size2)
							{
								up2=up=y;
								break;						
							}
						}
					}	
				}
				dn=dn2;				
				
			}
            if (bo_flg ==  1 && c0 < up2 - size2 )
			{
				bo_flg = 0;
				if(up2-dn>size4 )
				{
				
					 if(up2-up>size3 && up<Math.Min(Low[0],Close[1]))	{dn2=up;dn=up;}
					 else
					 {
						 double y=l0;					
						 for(int j=0;j<LookBack;j++)
						 {
						 	if(Low[j]<y)y=Low[j];
							if(dn>y)break;
							if(up2-y > size2 && Low[j] > y + size2)
							{
								dn2=dn=y;
								break;						
							}
						 }					
					}
				}
				up=up2;
				
			}
			if(up-dn > (max0-min0)*2)
			{
				up=up2=max0;
				dn=dn2=min0;
			}
			
				
			if (h0 > up + size1)  				{ bo_flg =  1;  }
            if (l0 < dn - size1)  				{ bo_flg = -1;  }

			
            
			
			Upper[0]=up;
			Lower[0]=dn;




        }

        #region Properties
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Upper
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Lower
		{
			get { return Values[1]; }
		}

		
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Size Damashi",
                                GroupName = "NinjaScriptParameters", Order = 0)]
        public double Size1
        { get; set; }
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Size Modoshi",
                                GroupName = "NinjaScriptParameters", Order = 1)]
        public double Size2
        { get; set; }
		
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Size Minimam Range",
                                GroupName = "NinjaScriptParameters", Order = 2)]
        public double Size3
        { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Size Maximam Range",
                                GroupName = "NinjaScriptParameters", Order = 3)]
        public double Size4
        { get; set; }
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Channel Period",
                                GroupName = "NinjaScriptParameters", Order = 4)]
        public int Period
        { get; set; }
		[Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "LookBack",
                                GroupName = "NinjaScriptParameters", Order = 5)]
        public int LookBack
        { get; set; }

		
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SnR[] cacheSnR;
		public SnR SnR(double size1, double size2, double size3, double size4, int period, int lookBack)
		{
			return SnR(Input, size1, size2, size3, size4, period, lookBack);
		}

		public SnR SnR(ISeries<double> input, double size1, double size2, double size3, double size4, int period, int lookBack)
		{
			if (cacheSnR != null)
				for (int idx = 0; idx < cacheSnR.Length; idx++)
					if (cacheSnR[idx] != null && cacheSnR[idx].Size1 == size1 && cacheSnR[idx].Size2 == size2 && cacheSnR[idx].Size3 == size3 && cacheSnR[idx].Size4 == size4 && cacheSnR[idx].Period == period && cacheSnR[idx].LookBack == lookBack && cacheSnR[idx].EqualsInput(input))
						return cacheSnR[idx];
			return CacheIndicator<SnR>(new SnR(){ Size1 = size1, Size2 = size2, Size3 = size3, Size4 = size4, Period = period, LookBack = lookBack }, input, ref cacheSnR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SnR SnR(double size1, double size2, double size3, double size4, int period, int lookBack)
		{
			return indicator.SnR(Input, size1, size2, size3, size4, period, lookBack);
		}

		public Indicators.SnR SnR(ISeries<double> input , double size1, double size2, double size3, double size4, int period, int lookBack)
		{
			return indicator.SnR(input, size1, size2, size3, size4, period, lookBack);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SnR SnR(double size1, double size2, double size3, double size4, int period, int lookBack)
		{
			return indicator.SnR(Input, size1, size2, size3, size4, period, lookBack);
		}

		public Indicators.SnR SnR(ISeries<double> input , double size1, double size2, double size3, double size4, int period, int lookBack)
		{
			return indicator.SnR(input, size1, size2, size3, size4, period, lookBack);
		}
	}
}

#endregion
