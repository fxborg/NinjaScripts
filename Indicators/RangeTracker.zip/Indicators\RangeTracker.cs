// Accelarated Moving Average v1.03     
// Copyright (C) 2016, fxborg<fxborg-labo.hateblo.jp>.
// http://fxborg-labo.hateblo.jp/ 
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

#endregion

//This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
    /// <summary>
    /// Accel Moving Average
    /// </summary>
    public class RangeTracker : Indicator
    {
		private int 										rangePos;
		private int 										upperPos;
		private double 										upper;
		private int 										lowerPos;
		private double 										lower;
		private int 										sigCnt=0;
		private int 										prevSig=0;
		private int 										dir=0;
		private int 										prev=0;
		private LasyATR										atr; 
		
		private FlexTrend			trend;
		private FlexSig				sig;
		
        
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                //---パラメータのデフォルト値を設定。
                Description                 = "RangeTracker";
                Name                        = "RangeTracker";
                IsSuspendedWhileInactive    = true;
                IsOverlay                   = true;
				Stop1=2;
				Stop2=4;
				SigSize=0.5;

				AddPlot(new Stroke(Brushes.Gold),  PlotStyle.TriangleDown, "Upper");
                AddPlot(new Stroke(Brushes.Gold),  PlotStyle.TriangleUp, "Lower");
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.TriangleUp, "Long");
                AddPlot(new Stroke(Brushes.Maroon),  PlotStyle.TriangleDown, "Short");
                AddPlot(new Stroke(Brushes.White),  PlotStyle.Hash, "UpLine");
                AddPlot(new Stroke(Brushes.White),  PlotStyle.Hash, "LoLine");
            }
            else if (State == State.Historical)
            {
                trend =FlexTrend(1.2,10);
				sig =FlexSig(SigSize);
				atr	= LasyATR(50);
				
				Plots[0].Width=2;        	
				Plots[1].Width=2;        	
				Plots[2].Width=5;        	
				Plots[3].Width=5;        	
				Plots[4].Width=2;        	
				Plots[5].Width=2;        	

				//---
            }
        }
        
        protected override void OnBarUpdate()
        {
            if(CurrentBar<2)return;
			//---
			double atr0=atr[0];
			double trend0 = trend[0];
			double sig0=sig[0];
			double sig1=sig[1];
			
			prev=dir;
			//---
			//+-------------------------------------------------+
			//| up trend 
			//+-------------------------------------------------+
			if(dir==  1 && upper<High[0])				{upper=High[0];upperPos=CurrentBar;}			// update upper price
			if(dir==  2 && lower>Low[0])				{lower=Low[0];lowerPos=CurrentBar;}				// update lower price

			if(dir==  2 && ((upper+upper+lower)/3.0)<Close[0]){dir= 3;prevSig=0;rangePos=CurrentBar;}	// 3rd sign
			if(dir==  1 && Close[0]<upper-atr0*Stop1)	{lower=Low[0];lowerPos=CurrentBar; dir=  2;}	// 2nd sign
			if( trend0> 1 && dir<=0)					{upper=High[0];upperPos=CurrentBar; dir=  1;}	// 1st sign

			if(dir==  2 && Close[0] < upper-atr0*Stop2)	{dir= 0;}										// break out	 
			if(dir==  3 && Close[0] < lower-(upper-lower)*0.25)	{dir= 0;}								// break out	 
			if(dir>=  2 && Close[0] > upper+(upper-lower)*0.25){upper=High[0];upperPos=CurrentBar; dir= 1; }	// continue trend
			//+-------------------------------------------------+
			//| down trend
			//+-------------------------------------------------+
			if(dir== -1 && lower>Low[0])				{lower=Low[0];lowerPos=CurrentBar;}				// update lower price
			if(dir== -2 && upper<High[0])				{upper=High[0];upperPos=CurrentBar;}			// update upper price

			if(dir== -2 && ((upper+lower+lower)/3.0)>Close[0]){dir= -3;prevSig=0;rangePos=CurrentBar;}	// 3rd sign
			if(dir== -1 && Close[0]>lower+atr0*Stop1) 	{upper=High[0];upperPos=CurrentBar; dir= -2;}	// 2nd sign
			if( trend0<-1 && dir>=0)	  				{lower=Low[0];lowerPos=CurrentBar; dir= -1;}	// 1st sign

			if(dir== -2 && Close[0] > lower+atr0*Stop2)	{dir= 0; }										// break out
			if(dir== -3 && Close[0] > upper+(upper-lower)*0.25)	{dir = 0; }								// break out
			if(dir<= -2 && Close[0] < lower-(upper-lower)*0.25)	{lower=Low[0]; lowerPos=CurrentBar; dir= -1; }	// continue trend				
			//+-------------------------------------------------+
			//| Range  
			//+-------------------------------------------------+
			int pos;
			if((dir==2 && prev<2) ||(dir==-3 && prev>-3))
			{
				pos=CurrentBar-upperPos;
				Upper[pos]=High[pos];
				PlotBrushes[0][pos] = Brushes.Gold;
			}
			if((dir== -2 && prev>-2)||(dir==3 && prev<3))
			{
				pos=CurrentBar-lowerPos;
				Lower[pos]=Low[pos];								
				PlotBrushes[1][pos] = Brushes.Gold;
			}
			//+-------------------------------------------------+
			//| Signals  
			//+-------------------------------------------------+
			if(dir==Math.Abs(3))
			{
				UpLine[0]=upper;
				LoLine[0]=lower;
			}
			
			
			if(dir==Math.Abs(3))
			{
				if(sig0==1  && sig1==-1)	{Long[0]=lower;prevSig= 1;}
				if(sig0==-1 && sig1==1) 	{Short[0]=upper;prevSig= -1;}
				if(prevSig==0 && CurrentBar-rangePos>=2)
				{
					double margin=(upper-lower)*0.3;
					if(sig0==1  && sig1==1 && Close[0]>upper-margin)	{Long[0]=lower;prevSig= 1;}
					if(sig0==-1 && sig1==-1 && Close[0]<lower+margin) 	{Short[0]=upper;prevSig= -1;}						
				}
			}
			if(dir!=Math.Abs(3) && prev==Math.Abs(3))
			{
				double margin=(UpLine[1]-LoLine[1])*0.3;
				if(sig0==1 && prevSig!=1 &&	Close[0]>UpLine[1]-margin && Close[0]<UpLine[1]+margin)	{Long[0]=lower; prevSig= 1;}
				if(sig0==-1 && prevSig!=-1 && Close[0]>LoLine[1]-margin && Close[0]<LoLine[1]+margin){Short[0]=upper;prevSig= -1;}								
			}
			
        }

        #region Properties
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Upper
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Lower
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Long
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Short
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> UpLine
		{
			get { return Values[4]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> LoLine
		{
			get { return Values[5]; }
		}

		
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Stop1",
                                GroupName = "NinjaScriptParameters", Order = 0)]
        public double Stop1
        { get; set; }
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Stop2",
                                GroupName = "NinjaScriptParameters", Order = 1)]
        public double Stop2
        { get; set; }
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Sig Size",
                                GroupName = "NinjaScriptParameters", Order = 2)]
        public double SigSize
        { get; set; }

		
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RangeTracker[] cacheRangeTracker;
		public RangeTracker RangeTracker(double stop1, double stop2, double sigSize)
		{
			return RangeTracker(Input, stop1, stop2, sigSize);
		}

		public RangeTracker RangeTracker(ISeries<double> input, double stop1, double stop2, double sigSize)
		{
			if (cacheRangeTracker != null)
				for (int idx = 0; idx < cacheRangeTracker.Length; idx++)
					if (cacheRangeTracker[idx] != null && cacheRangeTracker[idx].Stop1 == stop1 && cacheRangeTracker[idx].Stop2 == stop2 && cacheRangeTracker[idx].SigSize == sigSize && cacheRangeTracker[idx].EqualsInput(input))
						return cacheRangeTracker[idx];
			return CacheIndicator<RangeTracker>(new RangeTracker(){ Stop1 = stop1, Stop2 = stop2, SigSize = sigSize }, input, ref cacheRangeTracker);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RangeTracker RangeTracker(double stop1, double stop2, double sigSize)
		{
			return indicator.RangeTracker(Input, stop1, stop2, sigSize);
		}

		public Indicators.RangeTracker RangeTracker(ISeries<double> input , double stop1, double stop2, double sigSize)
		{
			return indicator.RangeTracker(input, stop1, stop2, sigSize);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RangeTracker RangeTracker(double stop1, double stop2, double sigSize)
		{
			return indicator.RangeTracker(Input, stop1, stop2, sigSize);
		}

		public Indicators.RangeTracker RangeTracker(ISeries<double> input , double stop1, double stop2, double sigSize)
		{
			return indicator.RangeTracker(input, stop1, stop2, sigSize);
		}
	}
}

#endregion
