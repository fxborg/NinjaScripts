// 
// Copyright (C) 2016, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// The Average True Range (LasyATR) is a measure of volatility. It was introduced by Welles Wilder 
	/// in his book 'New Concepts in Technical Trading Systems' and has since been used as a component 
	/// of many indicators and trading systems.
	/// </summary>
	public class LasyATR : Indicator
	{
		private double 									alpha;			// LasyATR用			

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionATR;
				Name						= "LasyATR";
				IsSuspendedWhileInactive	= true;
				Period						= 100;
				
				AddPlot(Brushes.Green, NinjaTrader.Custom.Resource.NinjaScriptIndicatorNameATR);
			}
			else if (State == State.Historical)
			{
				alpha=2.0/(Period+1.0);
			}
		}

		protected override void OnBarUpdate()
		{
			double high0	= High[0];
			double low0		= Low[0];
			
			if (CurrentBar == 0)
				Value[0] = high0 - low0;
			else
			{
				double close1		= Close[1];
				double atr1=Value[1];
			
 	 	     	double tr = Math.Max(high0,close1)-Math.Min(low0,close1);
		  		tr=Math.Max(atr1*0.667,Math.Min(tr,atr1*1.333));
          		Value[0]=alpha*tr+(1.0-alpha)*atr1;

			}
		}

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LasyATR[] cacheLasyATR;
		public LasyATR LasyATR(int period)
		{
			return LasyATR(Input, period);
		}

		public LasyATR LasyATR(ISeries<double> input, int period)
		{
			if (cacheLasyATR != null)
				for (int idx = 0; idx < cacheLasyATR.Length; idx++)
					if (cacheLasyATR[idx] != null && cacheLasyATR[idx].Period == period && cacheLasyATR[idx].EqualsInput(input))
						return cacheLasyATR[idx];
			return CacheIndicator<LasyATR>(new LasyATR(){ Period = period }, input, ref cacheLasyATR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LasyATR LasyATR(int period)
		{
			return indicator.LasyATR(Input, period);
		}

		public Indicators.LasyATR LasyATR(ISeries<double> input , int period)
		{
			return indicator.LasyATR(input, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LasyATR LasyATR(int period)
		{
			return indicator.LasyATR(Input, period);
		}

		public Indicators.LasyATR LasyATR(ISeries<double> input , int period)
		{
			return indicator.LasyATR(input, period);
		}
	}
}

#endregion
