#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class FlexLine : Indicator
	{
		private List<Series<double>> 					lines;　		// ステップライン用バッファ
		private Series<double>							line;			// トレンド用バッファ統合
		private Series<double> 							atr;			// ATR
		private int 									atrPeriod=100; // LasyATR用     
		private double 									atrAlpha;		// LasyATR用			
    	private EMA										ema;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"FlexLine";
				Name										= "FlexLine";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				// パラメータの初期値をセット
				StepSize=1.2;
				Level=0.5;
				Smoothing=10;
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				// インジケーターの出力設定
				AddPlot(new Stroke(Brushes.Red),  PlotStyle.Line,"LINE"); // ライン
				AddPlot(new Stroke(Brushes.Red),  PlotStyle.Line,"Upper"); // ライン
				AddPlot(new Stroke(Brushes.Red),  PlotStyle.Line,"Lower"); // ライン
			
			}
			else if (State == State.Configure)
			{
				       	
				atrAlpha=2.0/(atrPeriod+1.0);

			}
			else if (State == State.Historical)
			{


				atr			= new Series<double>(this);
				lines			= new List<Series<double>>();
				for(int i=0;i<6;i++)	lines.Add(new Series<double>(this));				
				line			= new Series<double>(this);
				ema				= EMA(line,Smoothing);
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.

            if(CurrentBar==0){
                atr[0]=High[0]-Low[0]; 
                return;
            }
			double atr0=atr[0];
            // LasyATRを計算
            calcLasyAtr();
            // StepLineを計算
            calcStepLines();
            //---
            double avg=0;
            for(int i=0;i<6;i++)	avg+=lines[i][0];
			line[0]=avg/6.0;
			Value[0]=ema[0];		
			Upper[0]=ema[0]+atr0*Level;
			Lower[0]=ema[0]-atr0*Level;
			
		}
        #region indicators
        //--- calc step lines
        private void calcStepLines()
        {
         
            double price=Typical[0];
            double rate=1.0;
            for(int i=0;i<6;i++)
            {
                double sz =atr[0]*StepSize*rate;
                //--- 
                if((price-sz)>lines[i][1]) lines[i][0]=price-sz;
                else if((price+sz)<lines[i][1]) lines[i][0]=price+sz;
                else lines[i][0]=lines[i][1];
                //---
                //---
                rate+=0.25;
            }  

        }
		//--- calc Lasy ATR
		private void calcLasyAtr()
		{
 	      double tr = Math.Max(High[0],Close[1])-Math.Min(Low[0],Close[1]);
		  tr=Math.Max(atr[1]*0.667,Math.Min(tr,atr[1]*1.333));
          atr[0]=atrAlpha*tr+(1.0-atrAlpha)*atr[1];
		}

		#endregion

		
		#region Properties
		
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Lower
		{
			get { return Values[2]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Upper
		{
			get { return Values[1]; }
		}

			
		// パラメータ ステップサイズ 
		[Range(0.01, 999.99), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Step Size",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public double StepSize
		{ get; set; }
		
		[Range(1, 9999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public int Smoothing
		{ get; set; }
		
		[Range(0, 9999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level",
								GroupName = "NinjaScriptParameters", Order = 3)]
		public double Level
		{ get; set; }

		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private FlexLine[] cacheFlexLine;
		public FlexLine FlexLine(double stepSize, int smoothing, double level)
		{
			return FlexLine(Input, stepSize, smoothing, level);
		}

		public FlexLine FlexLine(ISeries<double> input, double stepSize, int smoothing, double level)
		{
			if (cacheFlexLine != null)
				for (int idx = 0; idx < cacheFlexLine.Length; idx++)
					if (cacheFlexLine[idx] != null && cacheFlexLine[idx].StepSize == stepSize && cacheFlexLine[idx].Smoothing == smoothing && cacheFlexLine[idx].Level == level && cacheFlexLine[idx].EqualsInput(input))
						return cacheFlexLine[idx];
			return CacheIndicator<FlexLine>(new FlexLine(){ StepSize = stepSize, Smoothing = smoothing, Level = level }, input, ref cacheFlexLine);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.FlexLine FlexLine(double stepSize, int smoothing, double level)
		{
			return indicator.FlexLine(Input, stepSize, smoothing, level);
		}

		public Indicators.FlexLine FlexLine(ISeries<double> input , double stepSize, int smoothing, double level)
		{
			return indicator.FlexLine(input, stepSize, smoothing, level);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.FlexLine FlexLine(double stepSize, int smoothing, double level)
		{
			return indicator.FlexLine(Input, stepSize, smoothing, level);
		}

		public Indicators.FlexLine FlexLine(ISeries<double> input , double stepSize, int smoothing, double level)
		{
			return indicator.FlexLine(input, stepSize, smoothing, level);
		}
	}
}

#endregion
