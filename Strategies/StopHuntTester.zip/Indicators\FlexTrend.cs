// 
// Copyright (C) 2016, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// FlexTrend Bands are plotted at standard deviation levels above and below a moving average. 
	/// Since standard deviation is a measure of volatility, the bands are self-adjusting: 
	/// widening during volatile markets and contracting during calmer periods.
	/// </summary>
	public class FlexTrend : Indicator
	{

		private LasyATR  atr;
		private FlexLine line;
		private EMA		ema128;
		private EMA		flat;
		private EMA		flat2;
		private Series<double> abs;
		

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionBollinger;
				Name						= "FlexTrend";
				IsOverlay					= false;
				IsSuspendedWhileInactive	= true;

				AddPlot(Brushes.Red, "MIX VALUE");
			}
			else if (State == State.Configure)
			{
				line	= FlexLine(StepSize,Smoothing,1);
				ema128=EMA(128);
//				abs	= new Series<double>(this);
//				flat=EMA(abs,10000);
//				flat2=EMA(flat,10000);
				atr=LasyATR(100);
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBars[0]<=2)return; 

			double line0=line[0];
			double atr0=atr[0];
			Value[0]= Math.Max(Math.Min(2.8* (line0-ema128[0])/atr0,25.0),-25.0);
//			abs[0]=Math.Abs((line0-ema128[0])atr0);
//			Value[0]=flat2[0];
		}

		#region Properties
		// パラメータ ステップサイズ 
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> VALUE
		{
			get { return Values[0]; }
		}
		
		
		[Range(0.01, 999.99), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Step Size",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public double StepSize
		{ get; set; }
		[Range(1, 9999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public int Smoothing
		{ get; set; }

		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private FlexTrend[] cacheFlexTrend;
		public FlexTrend FlexTrend(double stepSize, int smoothing)
		{
			return FlexTrend(Input, stepSize, smoothing);
		}

		public FlexTrend FlexTrend(ISeries<double> input, double stepSize, int smoothing)
		{
			if (cacheFlexTrend != null)
				for (int idx = 0; idx < cacheFlexTrend.Length; idx++)
					if (cacheFlexTrend[idx] != null && cacheFlexTrend[idx].StepSize == stepSize && cacheFlexTrend[idx].Smoothing == smoothing && cacheFlexTrend[idx].EqualsInput(input))
						return cacheFlexTrend[idx];
			return CacheIndicator<FlexTrend>(new FlexTrend(){ StepSize = stepSize, Smoothing = smoothing }, input, ref cacheFlexTrend);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.FlexTrend FlexTrend(double stepSize, int smoothing)
		{
			return indicator.FlexTrend(Input, stepSize, smoothing);
		}

		public Indicators.FlexTrend FlexTrend(ISeries<double> input , double stepSize, int smoothing)
		{
			return indicator.FlexTrend(input, stepSize, smoothing);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.FlexTrend FlexTrend(double stepSize, int smoothing)
		{
			return indicator.FlexTrend(Input, stepSize, smoothing);
		}

		public Indicators.FlexTrend FlexTrend(ISeries<double> input , double stepSize, int smoothing)
		{
			return indicator.FlexTrend(input, stepSize, smoothing);
		}
	}
}

#endregion
