#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;

using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class RSISwitch : Indicator
	{
		        
		private Series<double> _regime;
		private EMA	_srsi;
		private RSI	_rsi;
		private Series<double> _flat;
		private Series<double> _trend;
		private double	_h1;
		private double	_h2;
		private double	_l1;
		private double　_l2;
		private List<Series<double>> _lines;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "RSISwitch";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				// パラメータの初期値をセット
				TrendLevel=20;
				SidewayLevel=5;
				Period=10;
				LookBack=30;
				StepSize=3;
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				// インジケーターの出力設定
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.Line,"Regime"); // ライン
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.Line,"RSI"); // ライン
				AddLine(Brushes.DarkViolet,		65,	NinjaTrader.Custom.Resource.NinjaScriptIndicatorUpper);
				AddLine(Brushes.DarkViolet,		35,	NinjaTrader.Custom.Resource.NinjaScriptIndicatorLower);
				AddLine(Brushes.DarkViolet,		50,	NinjaTrader.Custom.Resource.NinjaScriptIndicatorMiddle);
	
			}
			else if (State == State.Configure)
			{
				
				Plots[0].Width=4;        	
				
			}
			else if (State == State.Historical)
			{
				_lines			= new List<Series<double>>();
				for(int i=0;i<6;i++)_lines.Add(new Series<double>(this));
			
				_flat   = new Series<double>(this);
				_trend   = new Series<double>(this);
				_regime = new Series<double>(this);

				_rsi = RSI(Period,1); 
				_srsi = EMA(_rsi,LookBack); 
				_h1=50+SidewayLevel;
				_l1=50-SidewayLevel;
				_h2=50+TrendLevel;
				_l2=50-TrendLevel;

				
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar<=Period+LookBack+2 ) return;
			calcStepLines();
			_flat[0]=(_lines[0][0]+_lines[1][0]+_lines[2][0]+_lines[3][0]+_lines[4][0]+_lines[5][0])/6.0;
			//
			_trend[0] = (_flat[0]>_flat[1]) ? 1:
						(_flat[0]<_flat[1]) ? -1:
						_trend[1];
			

			if (_regime[1]!=1 && _flat[0]>_h1 && _trend[0]==1 && _rsi[0] > _h2) 
			{				
				_regime[0] = 1;				
			}
			else if(_regime[1]!= -1 && _flat[0]<_l1 && _trend[0]== -1 && _rsi[0] < _l2)
			{
				_regime[0] = -1;
			}
			else if(_regime[1]== 1 && _rsi[0]<=_l2) 
			{
				_regime[0] = 0;
			}
			else if(_regime[1]==-1 && _rsi[0]>=_h2) 
			{
				_regime[0] = 0;
			}
			else
			{
				_regime[0] = _regime[1] ;
			}				
	

		
				
			PlotBrushes[0][0] = _regime[0]==  1 ? Brushes.DarkGreen :
								_regime[0]== -1 ? Brushes.Maroon :
								Brushes.Yellow;
			Regime[0]=_regime[0];
			Rsi[0]=_rsi[0];
		}
			
        #region indicators
        private void calcStepLines()
        {
         
            double price=_srsi[0];
            double rate=1.0;
            for(int i=0;i<6;i++)
            {
                double sz =StepSize*rate;
                //--- 
                if((price-sz)>_lines[i][1]) _lines[i][0]=price-sz;
                else if((price+sz)<_lines[i][1]) _lines[i][0]=price+sz;
                else _lines[i][0]=_lines[i][1];
                //---
                rate+=0.25;
            }
			
		}
		
        #endregion

		
		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Rsi
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Regime
		{
			get { return Values[0]; }
		}
				
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public int Period
		{ get; set; }

		[Range(1,double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend Level",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public double TrendLevel
		{ get; set; }

		[Range(0.0,double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Sideway Level",
								GroupName = "NinjaScriptParameters", Order = 3)]
		public double SidewayLevel
		{ get; set; }
	

		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Look Back",
								GroupName = "NinjaScriptParameters", Order = 6)]
		public int LookBack
		{ get; set; }
		

		[Range(1,double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Step Size",
								GroupName = "NinjaScriptParameters", Order = 7)]
		public double StepSize
		{ get; set; }

		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RSISwitch[] cacheRSISwitch;
		public RSISwitch RSISwitch(int period, double trendLevel, double sidewayLevel, int lookBack, double stepSize)
		{
			return RSISwitch(Input, period, trendLevel, sidewayLevel, lookBack, stepSize);
		}

		public RSISwitch RSISwitch(ISeries<double> input, int period, double trendLevel, double sidewayLevel, int lookBack, double stepSize)
		{
			if (cacheRSISwitch != null)
				for (int idx = 0; idx < cacheRSISwitch.Length; idx++)
					if (cacheRSISwitch[idx] != null && cacheRSISwitch[idx].Period == period && cacheRSISwitch[idx].TrendLevel == trendLevel && cacheRSISwitch[idx].SidewayLevel == sidewayLevel && cacheRSISwitch[idx].LookBack == lookBack && cacheRSISwitch[idx].StepSize == stepSize && cacheRSISwitch[idx].EqualsInput(input))
						return cacheRSISwitch[idx];
			return CacheIndicator<RSISwitch>(new RSISwitch(){ Period = period, TrendLevel = trendLevel, SidewayLevel = sidewayLevel, LookBack = lookBack, StepSize = stepSize }, input, ref cacheRSISwitch);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RSISwitch RSISwitch(int period, double trendLevel, double sidewayLevel, int lookBack, double stepSize)
		{
			return indicator.RSISwitch(Input, period, trendLevel, sidewayLevel, lookBack, stepSize);
		}

		public Indicators.RSISwitch RSISwitch(ISeries<double> input , int period, double trendLevel, double sidewayLevel, int lookBack, double stepSize)
		{
			return indicator.RSISwitch(input, period, trendLevel, sidewayLevel, lookBack, stepSize);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RSISwitch RSISwitch(int period, double trendLevel, double sidewayLevel, int lookBack, double stepSize)
		{
			return indicator.RSISwitch(Input, period, trendLevel, sidewayLevel, lookBack, stepSize);
		}

		public Indicators.RSISwitch RSISwitch(ISeries<double> input , int period, double trendLevel, double sidewayLevel, int lookBack, double stepSize)
		{
			return indicator.RSISwitch(input, period, trendLevel, sidewayLevel, lookBack, stepSize);
		}
	}
}

#endregion
