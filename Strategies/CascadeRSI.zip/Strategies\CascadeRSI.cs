#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
    public class CascadeRSI : Strategy
    {
        #region private variables
		private RSISwitch								_rsi;			//rsi		
		private Cascade									_cascade;
        #endregion
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description                                 = @"Cascade RSI.";
                Name                                        = "CascadeRSI";
                Calculate                                   = Calculate.OnBarClose;
                EntriesPerDirection                         = 1;
                EntryHandling                               = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy                = true;
                ExitOnSessionCloseSeconds                   = 30;
                IsFillLimitOnTouch                          = false;
                MaximumBarsLookBack                         = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution                         = OrderFillResolution.Standard;
                Slippage                                    = 0;
                StartBehavior                               = StartBehavior.WaitUntilFlat;
                TimeInForce                                 = TimeInForce.Gtc;
                TraceOrders                                 = false;
                RealtimeErrorHandling                       = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling                          = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade                         = 10;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration   = true;

                // パラメータの初期値をセット
				TrendTF=1440;
                StepSize=1.2;
				RsiLevel=20;				
                Period1= 14;
				Period2= 45;
            }
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Minute, TrendTF);
		    }
			else if (State == State.Historical)
			{
				
   				// Series
				_cascade 		= Cascade(BarsArray[0],StepSize);
   				
				_rsi			 = RSISwitch(BarsArray[1],Period1, RsiLevel,0,Period2,2.5);
					
				
			}
        }

        protected override void OnBarUpdate()
        {
            //Add your custom indicator logic here.
            if(CurrentBars[0]<=2 || CurrentBars[1]<=2)     return;
		
			int regime=(int)_rsi.Regime[0];					
 	            
			int trend0 = (int)_cascade.Trend[0];
			int trend1 = (int)_cascade.Trend[1];
			//--- Exit Position
            if(MarketPosition.Long == Position.MarketPosition)
			{
				if(trend0<1 )ExitLong();
			}
            if(MarketPosition.Short== Position.MarketPosition)
			{
				if(trend0>-1)ExitShort();
			}
	        //---
            if(MarketPosition.Flat == Position.MarketPosition && trend0 >=  1  )             //上昇トレンド転換時            
	        {   
				if(regime ==1 )EnterLong(10000);

			}
        	else if(MarketPosition.Flat == Position.MarketPosition && trend0 <=  -1  )        //下降トレンド転換時
            {
				if(regime ==-1)EnterShort(10000);
			}
			
            //---           
        }

        #region Properties

        // パラメータ ステップサイズ 
        [Range(0.01, double.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Step Size",
                                GroupName = "NinjaScriptParameters", Order = 0)]
        public double StepSize
        { get; set; }


        // MA period
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "RSI Period",
                                GroupName = "NinjaScriptParameters", Order = 1)]
        public int Period1
        { get; set; }

        // MA period
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Avg Period ",
                                GroupName = "NinjaScriptParameters", Order = 2)]
        public int Period2
        { get; set; }
		
        // Rsi Level
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "RSI Level",
                                GroupName = "NinjaScriptParameters", Order = 3)]
        public int RsiLevel
        { get; set; }
		
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend TF",
								GroupName = "NinjaScriptParameters", Order = 4)]
		public int TrendTF
		{ get; set; }

		

        #endregion
    }
}