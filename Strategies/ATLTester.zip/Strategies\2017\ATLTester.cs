#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
    public class ATLTester : Strategy
    {
        #region private variables

		private int 										entryBar;
		private FlexTrend									trend;			
		private ATLSig		 								atl;
		private ZScore										z;		
		private int 										FromTime;
		private int 										ToTime;
		#endregion
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description                                 = @"Auto TL Tester.";
                Name                                        = "ATL Tester";
                Calculate                                   = Calculate.OnBarClose;
                EntriesPerDirection                         = 1;
                EntryHandling                               = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy                = true;
                ExitOnSessionCloseSeconds                   = 30;
                IsFillLimitOnTouch                          = false;
                MaximumBarsLookBack                         = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution                         = OrderFillResolution.Standard;
                Slippage                                    = 0;
                StartBehavior                               = StartBehavior.WaitUntilFlat;
                TimeInForce                                 = TimeInForce.Gtc;
                TraceOrders                                 = false;
                RealtimeErrorHandling                       = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling                          = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade                         = 10;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration   = true;
				FastPeriod=10;
				HiLoPeriod=25;
				ExitPeriod= 20;
				StartTime=8;
				Hours=16;
				TF=15;
				}
			else if (State == State.Configure)
			{
				
				AddDataSeries(Data.BarsPeriodType.Minute, TF);
		    }
			else if (State == State.Historical)
			{
				//---
				FromTime=StartTime*10000;
				ToTime=Math.Min(24,StartTime+Hours)*10000;				
				trend		= FlexTrend(BarsArray[1],1.2,10);
				atl = ATLSig(BarsArray[0],FastPeriod,HiLoPeriod,0.6);
				z= ZScore(BarsArray[1],50);
			}
        }

        protected override void OnBarUpdate()
        {
            //Add your custom indicator logic here.
           if(CurrentBars[0]<=3  || CurrentBars[1]<=3 )     return;
		   //---
		   double z0=z[0];
			double trend0=trend[0];
			//--- Exit Position
            if(MarketPosition.Long == Position.MarketPosition	&& CurrentBars[1] - entryBar >= ExitPeriod)
			{
				ExitLong();
			}
            if(MarketPosition.Short== Position.MarketPosition && CurrentBars[1] - entryBar >= ExitPeriod)
			{
				ExitShort();
			}
			
			if(MarketPosition.Flat == Position.MarketPosition && checktime(ToTime(Times[1][0]))  )                        
	        {
				if(atl.DnSig[0]>=1 && Closes[1][0]>atl.DnTL[0] && atl.DnTL[0]>0 && trend0>3 && z0<3.0 )
				{
						entryBar=CurrentBars[1];	
						EnterLong(10000);
				}
			}

			if(MarketPosition.Flat == Position.MarketPosition && checktime(ToTime(Times[1][0])) )        
            {
				if(atl.UpSig[0]>=1  && Closes[1][0]<atl.UpTL[0] && atl.UpTL[0]>0 && trend0<-3 && z0>-3.0 ) 
				{
						entryBar=CurrentBars[1];	
						EnterShort(10000);
				}
			}
        //---           
        }
		bool checktime(int now)
		{
			if((FromTime<=ToTime) && (now>=FromTime && now<ToTime))     return true;
	    	    
			if((FromTime>ToTime) && (now>=FromTime || now<ToTime))	return true;
        
			return false;
		}

		#region Properties

 
		[Range(1, 999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "FastPeriod",
								GroupName = "NinjaScriptParameters", Order = 0)]
		public int FastPeriod
		{ get; set; }

		
		[Range(1, 999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "HiLoPeriod",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public int HiLoPeriod
		{ get; set; }

		
		[Range(1, 1440), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "TF",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public int TF
		{ get; set; }

        // period
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Exit Period",
                                GroupName = "NinjaScriptParameters", Order = 3)]
        public int ExitPeriod
        { get; set; }

        [Range(0,24), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Start Time",
                                GroupName = "NinjaScriptParameters", Order = 4)]
        public int StartTime
        { get; set; }

        [Range(1, 24), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "hours",
                                GroupName = "NinjaScriptParameters", Order = 5)]
        public int Hours
        { get; set; }


        #endregion
    }
}
