#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ATLSig : Indicator
	{	
		private int LineNo=0;
		private int up_flg=0;
		private int dn_flg=0;
		private int up_i=0;
		private int dn_i=0;
		private double up=0;
		private double dn=0;
		private LasyATR	latr;
		private List<List<double>> LastHighCache;
		private List<List<double>> LastLowCache;

		private MAX hi;
		private MIN lo;
		private MAX hi2;
		private MIN lo2;

		private Series<double> upX1;
		private Series<double> upX2;
		private Series<double> upY1;
		private Series<double> upY2;
		
		private Series<double> dnX1;
		private Series<double> dnX2;
		private Series<double> dnY1;
		private Series<double> dnY2;

		private Series<double> upper;
		private Series<double> lower;
		private int upper_x=0;
		private int lower_x=0;
		private double xFactor=0.3;
//+-------			
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"ATLSig";
				Name										= "ATLSig";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				// パラメータの初期値をセット
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				// インジケーターの出力設定
                AddPlot(new Stroke(Brushes.Red),  PlotStyle.Bar,"UpSig"); 
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.Bar,"DnSig");  
                AddPlot(new Stroke(Brushes.Red),  PlotStyle.Line,"UpTL"); 
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.Line,"DnTL");  
				FastPeriod=20;
				HiLoPeriod=50;
				Threshold=0.6;
			}
			else if (State == State.Configure)
			{
				Plots[0].Width=5;        	
				Plots[1].Width=5;  
			}
			else if (State == State.Historical)
			{
				latr = LasyATR(100);
				LastHighCache = new List<List<double>>();
				LastLowCache = new List<List<double>>();
				hi = MAX(High,HiLoPeriod);
				lo = MIN(Low,HiLoPeriod);
				hi2 = MAX(High,FastPeriod);
				lo2 = MIN(Low,FastPeriod);
				upper = new Series<double>(this);
				lower = new Series<double>(this);

				upX1 = new Series<double>(this);
				upX2 = new Series<double>(this);
				upY1 = new Series<double>(this);
				upY2 = new Series<double>(this);

				dnX1 = new Series<double>(this);
				dnX2 = new Series<double>(this);
				dnY1 = new Series<double>(this);
				dnY2 = new Series<double>(this);

			}
		}

		protected override void OnBarUpdate()
		{
          
            if(CurrentBar<=Math.Max(FastPeriod,HiLoPeriod)+2)	return;
			//---
			UpSig[0]=UpSig[1];
			DnSig[0]=DnSig[1];
			//---
			upX1[0]=upX1[1];
			upX2[0]=upX2[1];
			upY1[0]=upY1[1];
			upY2[0]=upY2[1];
			//---
			dnX1[0]=dnX1[1];
			dnX2[0]=dnX2[1];
			dnY1[0]=dnY1[1];
			dnY2[0]=dnY2[1];
			double latr0=latr[0];
			//--
			if(hi[0]>hi[1])
			{
				upper[0]= hi[0];
				upper_x=CurrentBar;
				dn_i=CurrentBar;
				LastHighCache.Clear();
			}
			else
			{
				upper[0]=upper[1];
			}
			LastHighCache.Add(new List<double>{CurrentBar,High[0]});
			//--
			if(lo[0]<lo[1])
			{
				lower[0]= lo[0];
				lower_x=CurrentBar;
				up_i=CurrentBar;
				LastLowCache.Clear();
			}
			else
			{
				lower[0]=lower[1];
			}
			
			LastLowCache.Add(new List<double>{CurrentBar,Low[0]});
			//---
			if( CurrentBar-upper_x>FastPeriod)
			{				
				if(lo2[0]==Low[0])
				{
					LastHighCache=convex_upper(LastHighCache);							
					int sz = LastHighCache.Count;
					if(sz>1)
		           	{
			            double best_d=0;
			            int best=0;
						for(int j=0;j<sz-1;j++)
						{
							int x1 = (int)LastHighCache[j][0];
							int x2 = (int)LastHighCache[j+1][0];
							double y1 = LastHighCache[j][1];
							double y2 = LastHighCache[j+1][1];
							double d=dimension_dn(x1,y1,x2,y2,High.GetValueAt(upper_x),CurrentBar,latr[0]*xFactor);
							if(d>best_d)
							{
								best=j;
								best_d=d;
							}
						}
						if(best_d>0)
						{
							int x1 = (int)LastHighCache[best][0];
							int x2 = (int)LastHighCache[best+1][0];
							double y1 = High[CurrentBar-x1];
							double y2 = High[CurrentBar-x2];
							//---
							dnX1[0]=x1;
							dnX2[0]=x2;
							dnY1[0]=y1;
							dnY2[0]=y2;
							DnSig[0]=1;
							//---
						}
					}

				}			
				
			}
			if(DnSig[0]>=1)
			{
				
				double tl=dnTL(0);				
				if(DnSig[0]==1 && Close[0]>tl)					DnSig[0]=2;					
				if(DnSig[0]==2 && Close[0]>tl+Threshold*latr0)	DnSig[0]=0;										
				if(DnSig[0]!=2)	PlotBrushes[1][0] = Brushes.Transparent;
				else			PlotBrushes[1][0] = Brushes.Blue;
				DnTL[0]=tl;
			}

			if( CurrentBar-lower_x>FastPeriod)
			{				

				if(hi2[0]==High[0])
				{
					LastLowCache=convex_lower(LastLowCache);
					int sz = LastLowCache.Count;
					if(sz>1)
		           	{
			            double best_d=0;
			            int best=0;
						for(int j=0;j<sz-1;j++)
						{
							int x1 = (int)LastLowCache[j][0];
							int x2 = (int)LastLowCache[j+1][0];
							double y1 = LastLowCache[j][1];
							double y2 = LastLowCache[j+1][1];
							double d=dimension_up(x1,y1,x2,y2,Low.GetValueAt(lower_x),CurrentBar,latr[0]*xFactor);
							
							if(d>best_d)
							{
								best=j;
								best_d=d;
							}

						}
	
						if(best_d>0)
						{
							int x1 = (int)LastLowCache[best][0];
							int x2 = (int)LastLowCache[best+1][0];
							double y1 = Low[CurrentBar-x1];
							double y2 = Low[CurrentBar-x2];
							//---
							upX1[0]=x1;
							upX2[0]=x2;
							upY1[0]=y1;
							upY2[0]=y2;
							UpSig[0]=1;
							//---
							
						}
					}

				}

			}					
			if(UpSig[0]>=1)
			{
				double tl =upTL(0);
				if(UpSig[0]==1 && Close[0]<tl)						UpSig[0]=2;					
				if(UpSig[0]==2 && Close[0]<tl-Threshold*latr0)		UpSig[0]=0;										
				if(UpSig[0]!=2)	PlotBrushes[0][0] = Brushes.Transparent;
				else				PlotBrushes[0][0] = Brushes.Red;
				UpTL[0]=tl;
			}
			
			
		}
		private double upTL(int barAgo)
		{
			double x1=upX1[0];
			double x2=upX2[0];
			double y1=upY1[0];
			double y2=upY2[0];			
			double a= (y2-y1)/(x2-x1);
			double b= y1-a*x1;   //b=y-ax			
			return a*(CurrentBar-barAgo)+b;
							
		}
		private double dnTL(int barAgo)
		{
			double x1=dnX1[0];
			double x2=dnX2[0];
			double y1=dnY1[0];
			double y2=dnY2[0];	
			
			double a= (y2-y1)/(x2-x1);
			double b= y1-a*x1;   //b=y-ax			
			return a*(CurrentBar-barAgo)+b;
			
		}

		
		#region local methods
		//+------------------------------------------------------------------+
		//|                                                                  |
		//+------------------------------------------------------------------+
		List<List<double>> convex_upper(List<List<double>> upper)
		{

			int len=upper.Count;
			List<List<double>>convex = new List<List<double>>();
			convex.Capacity=len;
			int k=0;
			for(int j=0;j<len;j++)
 			{
				
				while(k>=2 && (cross(convex[k-2][0],convex[k-2][1], convex[k-1][0]
								,convex[k-1][1], upper[j][0], upper[j][1]))>=0)
    			{
				 convex.RemoveAt(k-1);
		         k--;
    			}
		        convex.Add(new List<double>{upper[j][0],upper[j][1]});
		        k++;			
	 		}			
			return convex;
	  	}
		//+------------------------------------------------------------------+
		//|                                                                  |
		//+------------------------------------------------------------------+
		List<List<double>> convex_lower(List<List<double>> lower)
		{
		
			int len=lower.Count;		
			List<List<double>>convex = new List<List<double>>();
			int k=0;
			for(int j=0;j<len;j++)
 			{

				while(k>=2 && (cross(convex[k-2][0],convex[k-2][1], convex[k-1][0]
								,convex[k-1][1], lower[j][0], lower[j][1]))<=0)
    			{
				 convex.RemoveAt(k-1);
		         k--;
    			}
		        convex.Add(new List<double>{lower[j][0],lower[j][1]});
		        k++;
			
	 		}			
			return convex;
	  	}

		//+------------------------------------------------------------------+
		//|                                                                  |
		//+------------------------------------------------------------------+
		double cross(double ox,double oy,
		             double ax,double ay,
		             double bx,double by_)
		  {
			  return ((ax - ox) * (by_ - oy) - (ay - oy) * (bx - ox));
		  }
		//+------------------------------------------------------------------+
		//|                                                                  |
		//+------------------------------------------------------------------+
		double dimension_dn(double x1,double y1,double x2,double  y2,double top,double i,double xfacter)
		{
			if(x1>=x2 || y1<=y2)return 0.0;
			double a= (y2-y1)/(x2-x1);
			double b=y1-a*x1;   //b=y-ax
			double x0=(top-b)/a;  //x=(y-b)/a
			double y3 = a*i+b;    //y=ax+b  
			return xfacter*(i-x0)*(top-y3);
		}
		
		//+------------------------------------------------------------------+
		//|                                                                  |
		//+------------------------------------------------------------------+
		double dimension_up(double x1,double y1,double x2,double  y2,double btm,double i,double xfacter)
		{
			if(x1>=x2 || y1>=y2)return 0.0;
			double a= (y2-y1)/(x2-x1);
			double b=y1-a*x1;   //b=y-ax
			double x0=(btm-b)/a;  //x=(y-b)/a
			double y3 = a*i+b;    //y=ax+b  
			return xfacter*(i-x0)*(y3-btm);
		}
		#endregion		

		#region Properties


		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpSig
		{
			get { return Values[0]; }
		}

				[Browsable(false)]
		[XmlIgnore]
		public Series<double> DnSig
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpTL
		{
			get { return Values[2]; }
		}

				[Browsable(false)]
		[XmlIgnore]
		public Series<double> DnTL
		{
			get { return Values[3]; }
		}
		
		[Range(1, 999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "FastPeriod",
								GroupName = "NinjaScriptParameters", Order = 0)]
		public int FastPeriod
		{ get; set; }

		
		[Range(1, 999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "HiLoPeriod",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public int HiLoPeriod
		{ get; set; }

		
		[Range(0, 999), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Threshold",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public double Threshold
		{ get; set; }

		
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ATLSig[] cacheATLSig;
		public ATLSig ATLSig(int fastPeriod, int hiLoPeriod, double threshold)
		{
			return ATLSig(Input, fastPeriod, hiLoPeriod, threshold);
		}

		public ATLSig ATLSig(ISeries<double> input, int fastPeriod, int hiLoPeriod, double threshold)
		{
			if (cacheATLSig != null)
				for (int idx = 0; idx < cacheATLSig.Length; idx++)
					if (cacheATLSig[idx] != null && cacheATLSig[idx].FastPeriod == fastPeriod && cacheATLSig[idx].HiLoPeriod == hiLoPeriod && cacheATLSig[idx].Threshold == threshold && cacheATLSig[idx].EqualsInput(input))
						return cacheATLSig[idx];
			return CacheIndicator<ATLSig>(new ATLSig(){ FastPeriod = fastPeriod, HiLoPeriod = hiLoPeriod, Threshold = threshold }, input, ref cacheATLSig);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ATLSig ATLSig(int fastPeriod, int hiLoPeriod, double threshold)
		{
			return indicator.ATLSig(Input, fastPeriod, hiLoPeriod, threshold);
		}

		public Indicators.ATLSig ATLSig(ISeries<double> input , int fastPeriod, int hiLoPeriod, double threshold)
		{
			return indicator.ATLSig(input, fastPeriod, hiLoPeriod, threshold);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ATLSig ATLSig(int fastPeriod, int hiLoPeriod, double threshold)
		{
			return indicator.ATLSig(Input, fastPeriod, hiLoPeriod, threshold);
		}

		public Indicators.ATLSig ATLSig(ISeries<double> input , int fastPeriod, int hiLoPeriod, double threshold)
		{
			return indicator.ATLSig(input, fastPeriod, hiLoPeriod, threshold);
		}
	}
}

#endregion
