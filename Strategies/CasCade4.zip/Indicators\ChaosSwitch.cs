#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;

using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChaosSwitch : Indicator
	{
		private double _coef1;
		private double _coef2;
		private double _coef3;
		private double _sq2;
		
		private MAX                                     _max; 
		private MIN                                     _min;
        private Series<double>                          _hl;         
        private SUM                                     _daySum;         
        private Series<double>                          _metric;         
		private SMA										_avgMetric;
		private Percentile								_percentile;
		private double 									_atrAlpha;		// LasyATR用			
		private List<double>							_rank;
	    private Series<double>                          _rawdata;         
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ChaosSwitch";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				// パラメータの初期値をセット
				ShortPeriod=10;
				LongPeriod=60;
				LookBack=200;
				Smoothing=10;
				_sq2=Math.Sqrt(2);
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				// インジケーターの出力設定
                AddPlot(new Stroke(Brushes.Blue),  PlotStyle.Line,"ChaosSwitch"); // ライン
			
			}
			else if (State == State.Configure)
			{
				Plots[0].Width=1;        	

  	      		double a,sq2;
		  		sq2=Math.Sqrt(2);
				// SuperSmoother Filter
				a = Math.Exp( (-sq2  * Math.PI) / (double)Smoothing );
				_coef2 = 2.0 * a * Math.Cos( (sq2 *Math.PI) / (double)Smoothing );
				_coef3 = -a * a;
				_coef1 = 1.0 - _coef2 - _coef3;

			}
			else if (State == State.Historical)
			{
				_rawdata	    = new Series<double>(this);
				_hl			    = new Series<double>(this);
				_metric			= new Series<double>(this);
				_max			= MAX(High,ShortPeriod);
				_min			= MIN(Low,ShortPeriod);
				_avgMetric		= SMA(_metric,LongPeriod);
				_daySum		    = SUM(_hl,ShortPeriod);
				_rank			= new List<double>();
				
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
            _hl[0]=High[0]-Low[0]; 
			//
            if(CurrentBar<ShortPeriod)               return;
			double range=_max[0]-_min[0];
			_metric[0] =(range > 0.0)?_daySum[0]/range : 0.0; 
			//
			if(CurrentBar<ShortPeriod+LongPeriod+LookBack+1)return;
			if(CurrentBar == ShortPeriod+LongPeriod+LookBack+1)
			{
				for (int x = LookBack; x > 0; x--) _rank.Add(_avgMetric[x]);
			}
			_rank.RemoveAt(0);
			_rank.Add(_avgMetric[1]);
			int cnt=_rank.Where(x => x <= _avgMetric[0]).Count();
			_rawdata[0]= ((double)cnt / LookBack);
			
			if(CurrentBar<ShortPeriod+LongPeriod+LookBack+3)return;			
			Line[0]=  _coef1  * _rawdata[0] + _coef2 * Line[1] + _coef3 * Line[2];			
		}
        #region indicators
        #endregion

		
		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Line
		{
			get { return Values[0]; }
		}
		
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Short Metric",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public int ShortPeriod
		{ get; set; }
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Long Metric",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public int LongPeriod
		{ get; set; }

		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Look Back",
								GroupName = "NinjaScriptParameters", Order = 3)]
		public int LookBack
		{ get; set; }
		
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing",
								GroupName = "NinjaScriptParameters", Order = 4)]
		public int Smoothing
		{ get; set; }

		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChaosSwitch[] cacheChaosSwitch;
		public ChaosSwitch ChaosSwitch(int shortPeriod, int longPeriod, int lookBack, int smoothing)
		{
			return ChaosSwitch(Input, shortPeriod, longPeriod, lookBack, smoothing);
		}

		public ChaosSwitch ChaosSwitch(ISeries<double> input, int shortPeriod, int longPeriod, int lookBack, int smoothing)
		{
			if (cacheChaosSwitch != null)
				for (int idx = 0; idx < cacheChaosSwitch.Length; idx++)
					if (cacheChaosSwitch[idx] != null && cacheChaosSwitch[idx].ShortPeriod == shortPeriod && cacheChaosSwitch[idx].LongPeriod == longPeriod && cacheChaosSwitch[idx].LookBack == lookBack && cacheChaosSwitch[idx].Smoothing == smoothing && cacheChaosSwitch[idx].EqualsInput(input))
						return cacheChaosSwitch[idx];
			return CacheIndicator<ChaosSwitch>(new ChaosSwitch(){ ShortPeriod = shortPeriod, LongPeriod = longPeriod, LookBack = lookBack, Smoothing = smoothing }, input, ref cacheChaosSwitch);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChaosSwitch ChaosSwitch(int shortPeriod, int longPeriod, int lookBack, int smoothing)
		{
			return indicator.ChaosSwitch(Input, shortPeriod, longPeriod, lookBack, smoothing);
		}

		public Indicators.ChaosSwitch ChaosSwitch(ISeries<double> input , int shortPeriod, int longPeriod, int lookBack, int smoothing)
		{
			return indicator.ChaosSwitch(input, shortPeriod, longPeriod, lookBack, smoothing);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChaosSwitch ChaosSwitch(int shortPeriod, int longPeriod, int lookBack, int smoothing)
		{
			return indicator.ChaosSwitch(Input, shortPeriod, longPeriod, lookBack, smoothing);
		}

		public Indicators.ChaosSwitch ChaosSwitch(ISeries<double> input , int shortPeriod, int longPeriod, int lookBack, int smoothing)
		{
			return indicator.ChaosSwitch(input, shortPeriod, longPeriod, lookBack, smoothing);
		}
	}
}

#endregion
