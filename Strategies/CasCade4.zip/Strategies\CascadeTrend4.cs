#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
    public class CascadeTrend4 : Strategy
    {
        #region private variables
		private SMA										_ma1;			//MA1		
		private SMA										_ma2;			//MA2		
		private Cascade									_cascade;
		private ChaosSwitch								_chaosSwitch;
        #endregion
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description                                 = @"Cascade Trend 4.";
                Name                                        = "CascadeTrend4";
                Calculate                                   = Calculate.OnBarClose;
                EntriesPerDirection                         = 1;
                EntryHandling                               = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy                = true;
                ExitOnSessionCloseSeconds                   = 30;
                IsFillLimitOnTouch                          = false;
                MaximumBarsLookBack                         = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution                         = OrderFillResolution.Standard;
                Slippage                                    = 0;
                StartBehavior                               = StartBehavior.WaitUntilFlat;
                TimeInForce                                 = TimeInForce.Gtc;
                TraceOrders                                 = false;
                RealtimeErrorHandling                       = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling                          = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade                         = 10;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration   = true;

                // パラメータの初期値をセット
                StepSize=1.0;
                MaPeriod=800;
		
            	ShortPeriod=10;
				LongPeriod=60;
				LookBack=200;
				Smoothing=10;
				TF=1440;
            }
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Minute, TF);
		    }
			else if (State == State.Historical)
			{
   				// Series
                _ma1            = SMA(BarsArray[0], MaPeriod);
                _ma2            = SMA(BarsArray[0], MaPeriod*5);
                _cascade 		= Cascade(BarsArray[0],StepSize);
   				_chaosSwitch    = ChaosSwitch(BarsArray[1],ShortPeriod,LongPeriod,LookBack,Smoothing);
			}
        }

        protected override void OnBarUpdate()
        {
            //Add your custom indicator logic here.
            if(CurrentBars[0]<=2)     return;
				
 	            
			int trend0 = (int)_cascade.Trend[0];
			int trend1 = (int)_cascade.Trend[1];
			//--- Exit Position
            if(MarketPosition.Long == Position.MarketPosition)
			{
				if(trend0<1 )ExitLong();
			}
            if(MarketPosition.Short== Position.MarketPosition)
			{
				if(trend0>-1)ExitShort();
			}
	        //---
            if(trend0 >=  2 && trend1 <  2 && _ma1[0]>_ma2[0])             //上昇トレンド転換時            
	        {   
				if(_chaosSwitch.Line[0]>=0.5)EnterLong();
			}
        	else if(trend0 <= -2 && trend1> -2 && _ma1[0]<_ma2[0])        //下降トレンド転換時
            {
				if(_chaosSwitch.Line[0]>=0.5)EnterShort();
			}
			
            //---           
        }

        #region Properties

        // パラメータ ステップサイズ 
        [Range(0.01, double.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Step Size",
                                GroupName = "NinjaScriptParameters", Order = 0)]
        public double StepSize
        { get; set; }

				
        // MA period
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "MA Period",
                                GroupName = "NinjaScriptParameters", Order = 3)]
        public int MaPeriod
        { get; set; }

		
		// Chaos Switch		
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Regime Short Metric",
								GroupName = "NinjaScriptParameters", Order = 4)]
		public int ShortPeriod
		{ get; set; }
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Regime Long Metric",
								GroupName = "NinjaScriptParameters", Order = 5)]
		public int LongPeriod
		{ get; set; }

		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Regime Look Back",
								GroupName = "NinjaScriptParameters", Order = 6)]
		public int LookBack
		{ get; set; }
		
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Regime Smoothing",
								GroupName = "NinjaScriptParameters", Order = 7)]
		public int Smoothing
		{ get; set; }
		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Regime TF",
								GroupName = "NinjaScriptParameters", Order = 8)]
		public int TF
		{ get; set; }
        #endregion
    }
}