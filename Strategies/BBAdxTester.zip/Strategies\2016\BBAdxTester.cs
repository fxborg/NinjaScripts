#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
    public class BBAdxTester : Strategy
    {
        #region private variables
		int _entryBar;
		private ZScore									z1;			
		private ZScore									z2;			
		private DM										adx;
		
		#endregion
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description                                 = @"BB & ADX Tester.";
                Name                                        = "BB & ADX Tester";
                Calculate                                   = Calculate.OnBarClose;
                EntriesPerDirection                         = 1;
                EntryHandling                               = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy                = true;
                ExitOnSessionCloseSeconds                   = 30;
                IsFillLimitOnTouch                          = false;
                MaximumBarsLookBack                         = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution                         = OrderFillResolution.Standard;
                Slippage                                    = 0;
                StartBehavior                               = StartBehavior.WaitUntilFlat;
                TimeInForce                                 = TimeInForce.Gtc;
                TraceOrders                                 = false;
                RealtimeErrorHandling                       = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling                          = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade                         = 10;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration   = true;

                // パラメータの初期値をセット
				BBPeriod1=20;				
				BBPeriod2=150;				
				Level1=2.0;				
				Level2=2.5;				
                ExitPeriod= 20;
				AdxPeriod=20;
				AdxLevel=30;
				}
			else if (State == State.Configure)
			{
		    }
			else if (State == State.Historical)
			{
				
   				// Series
				z1				= ZScore(BarsArray[0], BBPeriod1);
				z2				= ZScore(BarsArray[0], BBPeriod2);
				adx				= DM(AdxPeriod);
			}
        }

        protected override void OnBarUpdate()
        {
            //Add your custom indicator logic here.
          if(CurrentBars[0]<=6  )     return;

			double z1_0=z1.Z[0];					
			//---
			double z2_0=z2.Z[0];					
			double z2_1=z2.Z[1];					
			double z2_2=z2.Z[2];		
			
				
			//--- Exit Position
            if(MarketPosition.Long == Position.MarketPosition	&& CurrentBars[0] - _entryBar >= ExitPeriod)
			{
				ExitLong();
			}
            if(MarketPosition.Short== Position.MarketPosition && CurrentBars[0] - _entryBar>= ExitPeriod)
			{
				ExitShort();
			}
			//---

			if(MarketPosition.Flat == Position.MarketPosition  )                        
	        {   
				if(adx[0]>AdxLevel && adx.DiMinus[0]>adx.DiPlus[0]  &&  z1_0 < -Level1 && Math.Min(Math.Min(z2_0,z2_1),z2_2) > -Level2)
				{
					EnterLong(10000);
					_entryBar=CurrentBars[0];						
				}
			}
        	if(MarketPosition.Flat == Position.MarketPosition )        
            {
				if(adx[0]>AdxLevel && adx.DiMinus[0]<adx.DiPlus[0]  && z1_0 > Level1  &&  Math.Max(Math.Max(z2_0,z2_1),z2_2) < Level2)
				{
					EnterShort(10000);
					_entryBar=CurrentBars[0];
						
				}
			}
			
            //---           
        }

        #region Properties

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "1st BB Period",
                                GroupName = "NinjaScriptParameters", Order = 0)]
        public int BBPeriod1
        { get; set; }
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "2nd BB Period",
                                GroupName = "NinjaScriptParameters", Order = 1)]
        public int BBPeriod2
        { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "1st BB Level",
								GroupName = "NinjaScriptParameters", Order = 2)]
		public double Level1
		{ get; set; }			

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "2nd BB Level",
								GroupName = "NinjaScriptParameters", Order = 3)]
		public double Level2
		{ get; set; }			

		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ADX Period",
								GroupName = "NinjaScriptParameters", Order = 4)]
		public int AdxPeriod
		{ get; set; }

		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ADX Level",
								GroupName = "NinjaScriptParameters", Order = 5)]
		public int AdxLevel
		{ get; set; }

		
        // period
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Exit Period",
                                GroupName = "NinjaScriptParameters", Order = 6)]
        public int ExitPeriod
        { get; set; }

		

        #endregion
    }
}
