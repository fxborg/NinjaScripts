#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
    public class ZScoreTester : Strategy
    {
        #region private variables

		int 											_stat;
		int 											_entryBar;
		double  										_entryPrice;
		double  										_entryAtr;
		private MAX										_hi;
		private MIN										_lo;
		private ZScore									_z1;			
		private ZScore									_z2;			
		private Cascade									_cascade;
		private LasyATR									_atr; // LasyATR用     
		#endregion
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description                                 = @"Z-Score Tester";
                Name                                        = "ZScoreTester";
                Calculate                                   = Calculate.OnBarClose;
                EntriesPerDirection                         = 1;
                EntryHandling                               = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy                = true;
                ExitOnSessionCloseSeconds                   = 30;
                IsFillLimitOnTouch                          = false;
                MaximumBarsLookBack                         = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution                         = OrderFillResolution.Standard;
                Slippage                                    = 0;
                StartBehavior                               = StartBehavior.WaitUntilFlat;
                TimeInForce                                 = TimeInForce.Gtc;
                TraceOrders                                 = false;
                RealtimeErrorHandling                       = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling                          = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade                         = 10;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration   = true;

                // パラメータの初期値をセット
				TP1=3.0;
				SL1=3.0;
				TF1=60;
                StepSize=1.2;
				Period1=20;				
				Period2=100;
				Level1=2.0;				
				Level2=2.5;				
                ExitPeriod= 30;
				Averaging=1;				}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Minute, 1);
				AddDataSeries(Data.BarsPeriodType.Minute, TF1);
			}
			else if (State == State.Historical)
			{
				
   				// Series
				_cascade 		= Cascade(BarsArray[2],StepSize);
				_z1				= ZScore(BarsArray[0],Period1);
				_z2				= ZScore(BarsArray[0],Period2);
				_hi				= MAX(Highs[0],20);
				_lo				= MIN(Lows[0],20);
				_atr			= LasyATR(BarsArray[0],100);
			
			}
        }

        protected override void OnBarUpdate()
        {
            //Add your custom indicator logic here.
            if(CurrentBars[0]<=2 || CurrentBars[1]<=2|| CurrentBars[2]<=2 )     return;
			double z0=_z1.Z[0];					
			double z2=_z2.Z[0];					
			int trend0 = (int)_cascade.Trend[0];
			int trend1 = (int)_cascade.Trend[1];
			//--- Exit Position
			//--- long
			
			double k=(Averaging==1)?2.0:1.0;
			if(MarketPosition.Long == Position.MarketPosition	)
			{	
				if(CurrentBars[0] - _entryBar >= ExitPeriod)			ExitLong();
				else if(Closes[1][0]  >= _entryPrice+TP1*_entryAtr)		ExitLong();
	            else if(Closes[1][0]  <= _entryPrice - k*SL1*_entryAtr)		ExitLong();
				else if(Averaging==1 && _stat==0 && (Closes[1][0]  <= _entryPrice - SL1 * _entryAtr))
					{
						EnterLong(10000);
						_stat=1;
					}
						
			}
			//--- short			
			if(MarketPosition.Short== Position.MarketPosition)
			{	
				
				if(CurrentBars[0] - _entryBar>= ExitPeriod)				ExitShort();				
				else if(Closes[1][0] <=  _entryPrice-TP1*_entryAtr)		ExitShort();
				else if(Closes[1][0] >=  _entryPrice+ k*SL1 *_entryAtr)		ExitShort();
				else if(Averaging==1 && _stat==0 && (Closes[1][0] >=  _entryPrice + SL1 * _entryAtr))	
					{
						EnterShort(10000);
						_stat=1;
					}
				
			}
			//---
			if(MarketPosition.Flat == Position.MarketPosition  )                        
	        {   
				if(z0<-Level1 && z2>-Level2 )
				{
					if(trend0<=0) 						
					{
						
						if(_lo[1]<Closes[0][0])
						{
							EnterLong(10000);
							_entryBar=CurrentBars[0];	
							_entryPrice=Closes[0][0];
							_entryAtr=_atr[0];
							_stat=0;
						}
					}
				}
				if( z0>Level1 && z2<Level2 )
				{					
					if(trend0>=0)
					{
						if(_hi[1]> Closes[0][0])
						{
							EnterShort(10000);
							_entryBar=CurrentBars[0];
							_entryPrice=Closes[0][0];
							_entryAtr=_atr[0];
							_stat=0;
						}
					}
				}
			}
				
			
            //---           
        }

		
		#region Properties

        // パラメータ ステップサイズ 
        [Range(0.01, double.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Step Size",
                                GroupName = "NinjaScriptParameters", Order = 0)]
        public double StepSize
        { get; set; }

		[Range(1,int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Cascade TF",
								GroupName = "NinjaScriptParameters", Order = 1)]
		public int TF1
		{ get; set; }


        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Period1",
                                GroupName = "NinjaScriptParameters", Order = 4)]
        public int Period1
        { get; set; }
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Period2",
                                GroupName = "NinjaScriptParameters", Order = 5)]
        public int Period2
        { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level1", GroupName = "NinjaScriptParameters", Order = 6)]
		public double Level1
		{ get; set; }			

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level2", GroupName = "NinjaScriptParameters", Order = 7)]
		public double Level2
		{ get; set; }			
		

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Exit Period",
                                GroupName = "NinjaScriptParameters", Order = 8)]
        public int ExitPeriod
        { get; set; }

		[Range(0.1, 100.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Take Profit",
                                GroupName = "NinjaScriptParameters", Order = 9)]
        public double TP1
        { get; set; }
		[Range(0.1, 100.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Stop Loss",
                                GroupName = "NinjaScriptParameters", Order = 10)]
        public double SL1
        { get; set; }

		[Range(0, 1), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Averaging",
                                GroupName = "NinjaScriptParameters", Order = 11)]
        public int Averaging
        { get; set; }
		
		

        #endregion
    }
}
