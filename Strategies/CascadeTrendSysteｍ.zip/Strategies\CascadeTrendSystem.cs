// 
// Copyright (C) 2017, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds strategies in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class CascadeTrendSystem : Strategy
	{
		private CascadeTrend	trendFast;			
		private CascadeTrend	trendSlow;			

        private bool longready = false;
        private bool shortready = false;
        private bool exitlong = false;
        private bool exitshort = false;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description	= "CascadeTrendSystem";
 				Name		= "CascadeTrendSystem";
				Fast		= 1.8;
				Slow		= 2.2;
				
	        }
			else if (State == State.Configure)
			{
	
				AddDataSeries(BarsPeriodType.Tick, 1);
				
				trendFast= CascadeTrend(BarsArray[0],Fast,2);
				trendSlow= CascadeTrend(BarsArray[0],Slow,1);
				exitlong = false;
				exitshort = false;
				longready = false;
				shortready = false;
				AddChartIndicator(trendFast);
				AddChartIndicator(trendSlow);

			}
		}

		protected override void OnBarUpdate()
		{
			
           if(CurrentBars[0]<=BarsRequiredToTrade  ||
			   CurrentBars[1]<=BarsRequiredToTrade  )     return;
			

		   if (BarsInProgress == 0)
            {
				double str0=trendFast[0];
				double str1=trendFast[1];
				double trend0=trendSlow[0];
				double trend1=trendSlow[1];

				if(MarketPosition.Long == Position.MarketPosition	&& trend0==-1)
				{
					exitlong=true;					
				}
				if(MarketPosition.Short == Position.MarketPosition	&& trend0==1)
				{
					exitshort=true;					
				}


				if(MarketPosition.Flat == Position.MarketPosition)
				{
					if (Math.Abs(str0)!= 2 && str0!=str1   && trend0 == 1 )		longready=true;
					if (Math.Abs(str0)!= 2 && str0!=str1  && trend0 ==-1 )		shortready=true;
				}
			}
				
		   if (BarsInProgress == 1) // tick
            {
				if(exitshort)
				{
					ExitShort(1,10000,"Exit Short","Enter Short");
					exitshort=false;
					shortready=false;
				}
				if(longready)
				{
				    EnterLong(1,10000,"Enter Long");
					longready=false;
					exitlong=false;
				}
				if(exitlong)
				{
					ExitLong(1,10000,"Exit Long","Enter Long");
					exitlong=false;
				}				
				if(shortready)
				{
				    EnterShort(1,10000,"Enter Short");
					shortready=false;
				}	
			}
			
		}

		#region Properties
		[Range(0.1, 5.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast", GroupName = "NinjaScriptStrategyParameters", Order = 0)]
		public double Fast
		{ get; set; }
		[Range(0.1, 10.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow", GroupName = "NinjaScriptStrategyParameters", Order = 1)]
		public double Slow
		{ get; set; }


		#endregion
	}
}
