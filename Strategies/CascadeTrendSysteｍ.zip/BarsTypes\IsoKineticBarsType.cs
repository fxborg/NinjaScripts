#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds Bars types in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.BarsTypes
{
	
	public class IsoKineticBarsType : BarsType
	{

		private			const			int OHLC_OPEN = 0;
		private			const			int OHLC_HIGH = 1;
		private			const			int OHLC_LOW  = 2;
		private			const			int OHLC_CLOSE = 3;
		private			double			last_tick=0.0;
		private			double			accum_volat=0.0;
		private 		bool			firsttime=true;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{	
				Description									= @"IsoKinetic Bars Type";
				Name										= "IsoKineticBarsType";
				BuiltFrom									= BarsPeriodType.Tick;
				BarsPeriod									= new BarsPeriod { BarsPeriodType = (BarsPeriodType) 14, BarsPeriodTypeName = "IsoKineticBarsType(14)", Value = 1 };
				DaysToLoad									= 1;
				IsIntraday									= true;
				IsTimeBased									= false;
			}
			else if (State == State.Configure)
			{
				Properties.Remove(Properties.Find("BaseBarsPeriodType",			true));
				Properties.Remove(Properties.Find("BaseBarsPeriodValue",		true));
				Properties.Remove(Properties.Find("PointAndFigurePriceType",	true));
				Properties.Remove(Properties.Find("ReversalType",				true));
				Properties.Remove(Properties.Find("Value2",						true));
				last_tick=0.0;
				firsttime=true;
			}
		}

		public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack)
		{
			return 1; 
		}

		protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
		{
			
			
			if (SessionIterator == null)SessionIterator = new SessionIterator(bars);

			bool isNewSession = SessionIterator.IsNewSession(time, isBar);
			if (isNewSession)SessionIterator.GetNextSession(time, isBar);
			if(firsttime)
			{
				firsttime=false;
				Print("Isokinetic BarsType."+bars.BarsPeriod.Value);
				
				
			}
			//---
			double cut_points = bars.Instrument.MasterInstrument.TickSize; 
			if(!isNewSession && cut_points > Math.Abs(last_tick-close)) 
			{
				bars.LastPrice = close;
				return;
			}

			if (bars.Count == 0 || bars.LastPrice==0.0 || isNewSession)
			{
					AddBar(bars,  close, close, close, close , time, volume);
					last_tick = close;
					bars.LastPrice = close;
					accum_volat=0;		
			}
			else
			{
				
				double threshold = bars.BarsPeriod.Value * bars.Instrument.MasterInstrument.TickSize;						
		        // 価格差を計算
				double diff=close-bars.LastPrice;
				double adiff=Math.Abs(diff);
				int sign= (diff>=0) ? 1 : -1;

				double[] last_ohlc = new double[4];
				last_ohlc[OHLC_OPEN]	= bars.GetOpen(bars.Count - 1);
				last_ohlc[OHLC_HIGH]	= bars.GetHigh(bars.Count - 1);
				last_ohlc[OHLC_LOW]		= bars.GetLow(bars.Count - 1);
				last_ohlc[OHLC_CLOSE]	= bars.GetClose(bars.Count - 1);
				DateTime	lastBarTime		= bars.GetTime(bars.Count - 1);
				long		lastBarVolume	= bars.GetVolume(bars.Count - 1);
				//---
				if(accum_volat+adiff<threshold) {
					// しきい値に満たない場合
					update_bar(ref last_ohlc,close);
					UpdateBar(bars, last_ohlc[OHLC_HIGH], last_ohlc[OHLC_LOW], last_ohlc[OHLC_CLOSE] , time, volume);	
					accum_volat+=adiff;
				}
				else
				{
					//ボラティリティがしきい値を超えたのでバーを作る					
					double last_close = bars.LastPrice;
			        while(accum_volat+adiff>=threshold)
			        {
			            // 基準量ごとにバーを作る
			            double decrease=(threshold-accum_volat);
			            last_close=last_close+sign*decrease;
						update_bar(ref last_ohlc,last_close);
					
						//---
						UpdateBar(bars, last_ohlc[OHLC_HIGH], last_ohlc[OHLC_LOW], last_ohlc[OHLC_CLOSE] , time, volume);	
			            //---
			            accum_volat=0.0;
			            adiff-=decrease;
			            //---
						AddBar(bars,  last_close, last_close, last_close, last_close , time, 1);
						//---
						create_bar(ref last_ohlc,last_close);									
			        }

					if(adiff>0.0)
					{
						update_bar(ref last_ohlc,close);
						UpdateBar(bars, last_ohlc[OHLC_HIGH], last_ohlc[OHLC_LOW], last_ohlc[OHLC_CLOSE] , time, volume);	
					}
		            accum_volat=0.0;			
				}
				bars.LastPrice = close;
			}
			
		}

		public override void ApplyDefaultBasePeriodValue(BarsPeriod period)
		{
		}

		public override void ApplyDefaultValue(BarsPeriod period)
		{
			period.BarsPeriodTypeName	= "Bar Size (in Points)";
			period.Value				= 150;
		}

		public override string ChartLabel(DateTime dateTime)
		{
			return dateTime.ToString("T", Core.Globals.GeneralOptions.CurrentCulture);
		}

		public override double GetPercentComplete(Bars bars, DateTime now)
		{
			return 0;
		}
		void create_bar(ref double[] ohlc, double v)
		  {
		   ohlc[OHLC_OPEN]=v; 
		   ohlc[OHLC_HIGH]=v;
		   ohlc[OHLC_LOW]=v;
		   ohlc[OHLC_CLOSE]=v;
		  }
		void update_bar(ref double[] ohlc,double v)
		  {
		   if(ohlc[OHLC_LOW]>v) ohlc[OHLC_LOW]=v;
		   if(ohlc[OHLC_HIGH]<v) ohlc[OHLC_HIGH]=v;
		   ohlc[OHLC_CLOSE]=v;
		  }

		  
	   int GetWeekOfYear(DateTime t)
		{
		    return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(t, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Sunday);
		} 
	}
}
